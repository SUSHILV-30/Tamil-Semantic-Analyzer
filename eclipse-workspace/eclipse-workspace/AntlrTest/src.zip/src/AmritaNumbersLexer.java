// Generated from AmritaNumbersLexer.g4 by ANTLR 4.13.2
import org.antlr.v4.runtime.Lexer;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.misc.*;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue", "this-escape"})
public class AmritaNumbersLexer extends Lexer {
	static { RuntimeMetaData.checkVersion("4.13.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		IF=1, REAL=2, BIN=3, OCT=4, DEC=5, HEX=6, RL=7, WS=8;
	public static String[] channelNames = {
		"DEFAULT_TOKEN_CHANNEL", "HIDDEN"
	};

	public static String[] modeNames = {
		"DEFAULT_MODE"
	};

	private static String[] makeRuleNames() {
		return new String[] {
			"IF", "REAL", "BIN", "OCT", "DEC", "HEX", "RL", "WS"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'if'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "IF", "REAL", "BIN", "OCT", "DEC", "HEX", "RL", "WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}


	public AmritaNumbersLexer(CharStream input) {
		super(input);
		_interp = new LexerATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@Override
	public String getGrammarFileName() { return "AmritaNumbersLexer.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public String[] getChannelNames() { return channelNames; }

	@Override
	public String[] getModeNames() { return modeNames; }

	@Override
	public ATN getATN() { return _ATN; }

	public static final String _serializedATN =
		"\u0004\u0000\b\u007f\u0006\uffff\uffff\u0002\u0000\u0007\u0000\u0002\u0001"+
		"\u0007\u0001\u0002\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004"+
		"\u0007\u0004\u0002\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007"+
		"\u0007\u0007\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0001\u0003\u0001"+
		"\u0016\b\u0001\u0001\u0001\u0004\u0001\u0019\b\u0001\u000b\u0001\f\u0001"+
		"\u001a\u0001\u0001\u0001\u0001\u0004\u0001\u001f\b\u0001\u000b\u0001\f"+
		"\u0001 \u0001\u0001\u0001\u0001\u0004\u0001%\b\u0001\u000b\u0001\f\u0001"+
		"&\u0001\u0001\u0004\u0001*\b\u0001\u000b\u0001\f\u0001+\u0001\u0001\u0001"+
		"\u0001\u0004\u00010\b\u0001\u000b\u0001\f\u00011\u0003\u00014\b\u0001"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0004\u0002:\b\u0002"+
		"\u000b\u0002\f\u0002;\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003"+
		"\u0004\u0003B\b\u0003\u000b\u0003\f\u0003C\u0001\u0004\u0001\u0004\u0001"+
		"\u0004\u0001\u0004\u0004\u0004J\b\u0004\u000b\u0004\f\u0004K\u0001\u0005"+
		"\u0001\u0005\u0001\u0005\u0001\u0005\u0004\u0005R\b\u0005\u000b\u0005"+
		"\f\u0005S\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006"+
		"\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0003\u0006"+
		"`\b\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0003\u0006"+
		"f\b\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006"+
		"\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0003\u0006q\b\u0006"+
		"\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006"+
		"\u0001\u0007\u0004\u0007z\b\u0007\u000b\u0007\f\u0007{\u0001\u0007\u0001"+
		"\u0007\u0000\u0000\b\u0001\u0001\u0003\u0002\u0005\u0003\u0007\u0004\t"+
		"\u0005\u000b\u0006\r\u0007\u000f\b\u0001\u0000\u0007\u0002\u0000++--\u0001"+
		"\u000009\u0001\u000001\u0001\u000007\u0003\u000009AFaf\u0001\u000015\u0003"+
		"\u0000\t\n\r\r  \u0090\u0000\u0001\u0001\u0000\u0000\u0000\u0000\u0003"+
		"\u0001\u0000\u0000\u0000\u0000\u0005\u0001\u0000\u0000\u0000\u0000\u0007"+
		"\u0001\u0000\u0000\u0000\u0000\t\u0001\u0000\u0000\u0000\u0000\u000b\u0001"+
		"\u0000\u0000\u0000\u0000\r\u0001\u0000\u0000\u0000\u0000\u000f\u0001\u0000"+
		"\u0000\u0000\u0001\u0011\u0001\u0000\u0000\u0000\u0003\u0015\u0001\u0000"+
		"\u0000\u0000\u00055\u0001\u0000\u0000\u0000\u0007=\u0001\u0000\u0000\u0000"+
		"\tE\u0001\u0000\u0000\u0000\u000bM\u0001\u0000\u0000\u0000\rU\u0001\u0000"+
		"\u0000\u0000\u000fy\u0001\u0000\u0000\u0000\u0011\u0012\u0005i\u0000\u0000"+
		"\u0012\u0013\u0005f\u0000\u0000\u0013\u0002\u0001\u0000\u0000\u0000\u0014"+
		"\u0016\u0007\u0000\u0000\u0000\u0015\u0014\u0001\u0000\u0000\u0000\u0015"+
		"\u0016\u0001\u0000\u0000\u0000\u00163\u0001\u0000\u0000\u0000\u0017\u0019"+
		"\u0007\u0001\u0000\u0000\u0018\u0017\u0001\u0000\u0000\u0000\u0019\u001a"+
		"\u0001\u0000\u0000\u0000\u001a\u0018\u0001\u0000\u0000\u0000\u001a\u001b"+
		"\u0001\u0000\u0000\u0000\u001b\u001c\u0001\u0000\u0000\u0000\u001c\u001e"+
		"\u0005.\u0000\u0000\u001d\u001f\u0007\u0001\u0000\u0000\u001e\u001d\u0001"+
		"\u0000\u0000\u0000\u001f \u0001\u0000\u0000\u0000 \u001e\u0001\u0000\u0000"+
		"\u0000 !\u0001\u0000\u0000\u0000!4\u0001\u0000\u0000\u0000\"$\u0005.\u0000"+
		"\u0000#%\u0007\u0001\u0000\u0000$#\u0001\u0000\u0000\u0000%&\u0001\u0000"+
		"\u0000\u0000&$\u0001\u0000\u0000\u0000&\'\u0001\u0000\u0000\u0000\'4\u0001"+
		"\u0000\u0000\u0000(*\u0007\u0001\u0000\u0000)(\u0001\u0000\u0000\u0000"+
		"*+\u0001\u0000\u0000\u0000+)\u0001\u0000\u0000\u0000+,\u0001\u0000\u0000"+
		"\u0000,-\u0001\u0000\u0000\u0000-4\u0005.\u0000\u0000.0\u0007\u0001\u0000"+
		"\u0000/.\u0001\u0000\u0000\u000001\u0001\u0000\u0000\u00001/\u0001\u0000"+
		"\u0000\u000012\u0001\u0000\u0000\u000024\u0001\u0000\u0000\u00003\u0018"+
		"\u0001\u0000\u0000\u00003\"\u0001\u0000\u0000\u00003)\u0001\u0000\u0000"+
		"\u00003/\u0001\u0000\u0000\u00004\u0004\u0001\u0000\u0000\u000056\u0005"+
		"0\u0000\u000067\u0005b\u0000\u000079\u0001\u0000\u0000\u00008:\u0007\u0002"+
		"\u0000\u000098\u0001\u0000\u0000\u0000:;\u0001\u0000\u0000\u0000;9\u0001"+
		"\u0000\u0000\u0000;<\u0001\u0000\u0000\u0000<\u0006\u0001\u0000\u0000"+
		"\u0000=>\u00050\u0000\u0000>?\u0005o\u0000\u0000?A\u0001\u0000\u0000\u0000"+
		"@B\u0007\u0003\u0000\u0000A@\u0001\u0000\u0000\u0000BC\u0001\u0000\u0000"+
		"\u0000CA\u0001\u0000\u0000\u0000CD\u0001\u0000\u0000\u0000D\b\u0001\u0000"+
		"\u0000\u0000EF\u00050\u0000\u0000FG\u0005d\u0000\u0000GI\u0001\u0000\u0000"+
		"\u0000HJ\u0007\u0001\u0000\u0000IH\u0001\u0000\u0000\u0000JK\u0001\u0000"+
		"\u0000\u0000KI\u0001\u0000\u0000\u0000KL\u0001\u0000\u0000\u0000L\n\u0001"+
		"\u0000\u0000\u0000MN\u00050\u0000\u0000NO\u0005x\u0000\u0000OQ\u0001\u0000"+
		"\u0000\u0000PR\u0007\u0004\u0000\u0000QP\u0001\u0000\u0000\u0000RS\u0001"+
		"\u0000\u0000\u0000SQ\u0001\u0000\u0000\u0000ST\u0001\u0000\u0000\u0000"+
		"T\f\u0001\u0000\u0000\u0000UV\u0005C\u0000\u0000VW\u0005B\u0000\u0000"+
		"WX\u0005.\u0000\u0000X_\u0001\u0000\u0000\u0000YZ\u0005S\u0000\u0000Z"+
		"[\u0005C\u0000\u0000[`\u0005.\u0000\u0000\\]\u0005E\u0000\u0000]^\u0005"+
		"N\u0000\u0000^`\u0005.\u0000\u0000_Y\u0001\u0000\u0000\u0000_\\\u0001"+
		"\u0000\u0000\u0000`e\u0001\u0000\u0000\u0000ab\u0005U\u0000\u0000bf\u0005"+
		"4\u0000\u0000cd\u0005P\u0000\u0000df\u00055\u0000\u0000ea\u0001\u0000"+
		"\u0000\u0000ec\u0001\u0000\u0000\u0000fp\u0001\u0000\u0000\u0000gh\u0005"+
		"C\u0000\u0000hi\u0005S\u0000\u0000iq\u0005E\u0000\u0000jk\u0005A\u0000"+
		"\u0000kl\u0005I\u0000\u0000lq\u0005E\u0000\u0000mn\u0005C\u0000\u0000"+
		"no\u0005Y\u0000\u0000oq\u0005S\u0000\u0000pg\u0001\u0000\u0000\u0000p"+
		"j\u0001\u0000\u0000\u0000pm\u0001\u0000\u0000\u0000qr\u0001\u0000\u0000"+
		"\u0000rs\u00052\u0000\u0000st\u0007\u0005\u0000\u0000tu\u0007\u0001\u0000"+
		"\u0000uv\u0007\u0001\u0000\u0000vw\u0007\u0001\u0000\u0000w\u000e\u0001"+
		"\u0000\u0000\u0000xz\u0007\u0006\u0000\u0000yx\u0001\u0000\u0000\u0000"+
		"z{\u0001\u0000\u0000\u0000{y\u0001\u0000\u0000\u0000{|\u0001\u0000\u0000"+
		"\u0000|}\u0001\u0000\u0000\u0000}~\u0006\u0007\u0000\u0000~\u0010\u0001"+
		"\u0000\u0000\u0000\u0010\u0000\u0015\u001a &+13;CKS_ep{\u0001\u0006\u0000"+
		"\u0000";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}