lexer grammar AmritaNumbersLexer;

IF     : 'if' ;

REAL
    : ('+' | '-')?               // optional sign
      (
          [0-9]+ '.' [0-9]+      // 12.56
        | '.' [0-9]+             // .45
        | [0-9]+ '.'             // 45.
        | [0-9]+                 // integer like 50
      )
    ;

BIN    : '0b' [0-1]+ ;
OCT    : '0o' [0-7]+ ;
DEC    : '0d' [0-9]+ ;
HEX    : '0x' [0-9a-fA-F]+ ;

RL
    : 'CB.'
      ('SC.' | 'EN.')
      ('U4' | 'P5')
      ('CSE' | 'AIE' | 'CYS')
      '2'
      [1-5]
      [0-9] [0-9] [0-9]
    ;


WS : [ \t\r\n]+ -> skip ;